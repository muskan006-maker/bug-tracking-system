<div class="clear"></div>
<div id="footer">
    <ul class="right">
    	<li></li>
    </ul>
    <div class="clear"></div>
</div>
</body>
</html>

<div style="margin-bottom:15px;"><img src="images/save_1.jpg" style="width: 250px"></div>
<div><img src="images/save_2.jpg" style="width: 250px"></div>